# Electric Motor Temperature Prediction

This project predicts electric motor temperature using machine learning.

## Steps
1. Install requirements
2. Train model
3. Evaluate
4. Predict
5. Run web app
