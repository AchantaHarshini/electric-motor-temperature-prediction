import streamlit as st
import joblib
import numpy as np

model = joblib.load("models/model.pkl")
scaler = joblib.load("models/scaler.pkl")

st.title("Electric Motor Temperature Prediction")

current = st.number_input("Current (A)")
voltage = st.number_input("Voltage (V)")
speed = st.number_input("Speed (RPM)")
torque = st.number_input("Torque (Nm)")
ambient = st.number_input("Ambient Temperature (°C)")

if st.button("Predict"):
    input_data = np.array([[current, voltage, speed, torque, ambient]])
    input_scaled = scaler.transform(input_data)
    prediction = model.predict(input_scaled)

    st.success(f"Predicted Motor Temperature: {prediction[0]:.2f} °C")
