import joblib
import numpy as np

def predict_temperature(input_data):
    model = joblib.load("models/model.pkl")
    scaler = joblib.load("models/scaler.pkl")

    input_scaled = scaler.transform([input_data])
    prediction = model.predict(input_scaled)

    return prediction[0]

if __name__ == "__main__":
    sample_input = [12.5, 220, 1450, 8.2, 30]
    result = predict_temperature(sample_input)
    print("Predicted Motor Temperature:", result)
